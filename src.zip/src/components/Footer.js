import React from 'react'

const Footer = () => {

    return(
        <div>
            <div className="footer columns is-flex is-justify-content-center is-align-items-center mt-4 pt-3 pb-3 has-background-dark has-text-light">
                <p>Seyi Odediran © 2021</p>
            </div>
        </div>
    )
};

export default Footer;